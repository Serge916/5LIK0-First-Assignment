clear;

% Load the variables ....
load("data2.mat")

% part a


% part b


% part c


% clear eveything except the required answers
clearvars -EXCEPT v B C;
