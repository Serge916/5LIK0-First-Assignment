clear;

% part a


% part b


% part c


% part d


% part e


% clear eveything except the required answers
clearvars -EXCEPT U V A x b;
