clear;

% Load the variables ....
load("data4.mat")



% clear eveything except the required answers
clearvars -EXCEPT a b c