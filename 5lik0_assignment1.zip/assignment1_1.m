clear;

% Load the variables ....
load("data1.mat")

% part a


% part b


% part c


% part d


% part e


% clear eveything except the required answers
clearvars -EXCEPT a1 a2 V x U e;
