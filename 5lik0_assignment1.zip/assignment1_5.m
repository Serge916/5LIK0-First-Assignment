clear;

% Load the variables ....
load("data5.mat")

% part a


% part b


% clear eveything except the required answers
clearvars -EXCEPT W1 E1 I1 W2 E2 A2 I2;